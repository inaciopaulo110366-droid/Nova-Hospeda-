import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import { getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import type { DecodedIdToken } from 'firebase-admin/auth';
import firebaseConfig from './firebase-applet-config.json' with { type: 'json' };
import {
  BOOTSTRAPPED_ADMIN_EMAIL,
  PRIMARY_DOMAIN,
  detectEntryHtml,
  generateAvailableDomainSuggestions,
  getMimeType,
  safelyExtractZip,
  sanitizeRelativePath,
  validateStaticFileExtension,
  validateSubdomainSlug,
} from './src/server/security.ts';
import type { ExtractedFile } from './src/server/security.ts';
import { analyzeAndFixSiteWithAI } from './src/server/aiFixer.ts';
import { createStorageProvider } from './src/server/storage.ts';
import {
  addSecurityLog,
  findSiteBySlug,
  findUserSites,
  getStore,
  getUserStorageUsed,
  persistStore,
  recordRealVisit,
} from './src/server/store.ts';
import type {
  AbuseReportRecord,
  AnnouncementRecord,
  DeploymentRecord,
  DeploymentSourceType,
  SiteRecord,
  UserRecord,
} from './src/server/types.ts';

if (!getApps().length) {
  initializeApp({
    projectId: firebaseConfig.projectId,
  });
}

const adminAuth = getAuth();
const storage = createStorageProvider();

// Ephemeral HMAC key generated per server boot for preview tokens (never exposed to clients)
const PREVIEW_SECRET = process.env.PREVIEW_SIGNING_SECRET || crypto.randomBytes(32).toString('hex');

interface AuthRequest extends Request {
  authUser?: DecodedIdToken;
  userRecord?: UserRecord;
}

function getClientIp(req: Request): string {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length > 0) {
    return fwd.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || 'unknown';
}

function isBootstrappedAdmin(token: DecodedIdToken): boolean {
  return (
    token.email === BOOTSTRAPPED_ADMIN_EMAIL &&
    token.email_verified === true
  );
}

function createPreviewToken(siteId: string, uid: string): string {
  const expiresAt = Date.now() + 30 * 60 * 1000;
  const payload = `${siteId}:${uid}:${expiresAt}`;
  const sig = crypto.createHmac('sha256', PREVIEW_SECRET).update(payload).digest('hex');
  return Buffer.from(`${payload}:${sig}`).toString('base64url');
}

function verifyPreviewToken(token: string, siteId: string): boolean {
  try {
    const decoded = Buffer.from(token, 'base64url').toString('utf8');
    const parts = decoded.split(':');
    if (parts.length !== 4) return false;
    const [tokSiteId, uid, expStr, sig] = parts;
    if (tokSiteId !== siteId) return false;
    const exp = Number(expStr);
    if (!Number.isFinite(exp) || Date.now() > exp) return false;
    const expectedSig = crypto
      .createHmac('sha256', PREVIEW_SECRET)
      .update(`${tokSiteId}:${uid}:${expStr}`)
      .digest('hex');
    const a = Buffer.from(sig);
    const b = Buffer.from(expectedSig);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

function getCookieValue(req: Request, name: string): string {
  const raw = req.headers.cookie;
  if (!raw) return '';
  for (const part of raw.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    if (key === name) {
      return decodeURIComponent(part.slice(idx + 1).trim());
    }
  }
  return '';
}

function extractTokenFromReferer(req: Request): string {
  const ref = req.headers.referer;
  if (typeof ref !== 'string' || !ref) return '';
  try {
    const parsed = new URL(ref);
    return parsed.searchParams.get('token') || '';
  } catch {
    return '';
  }
}

async function requireAuth(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Autenticação necessária. Faça login para continuar.' });
    return;
  }

  const idToken = authHeader.slice('Bearer '.length).trim();
  if (!idToken) {
    res.status(401).json({ error: 'Token de autenticação ausente.' });
    return;
  }

  try {
    const decoded = await adminAuth.verifyIdToken(idToken);
    req.authUser = decoded;
    const store = getStore();
    const existing = store.users[decoded.uid];
    if (existing) {
      if (existing.status === 'suspended' && !isBootstrappedAdmin(decoded)) {
        res.status(403).json({
          error: 'Sua conta está suspensa pela administração. Entre em contato com o suporte.',
        });
        return;
      }
      req.userRecord = existing;
    }
    next();
  } catch {
    res.status(401).json({ error: 'Sessão inválida ou expirada. Faça login novamente.' });
  }
}

function requireVerifiedEmail(req: AuthRequest, res: Response, next: NextFunction): void {
  if (!req.authUser) {
    res.status(401).json({ error: 'Não autenticado.' });
    return;
  }
  if (!req.authUser.email_verified) {
    res.status(403).json({
      error: 'Confirme seu endereço de e-mail antes de criar ou publicar sites.',
      code: 'EMAIL_NOT_VERIFIED',
    });
    return;
  }
  next();
}

function requireAdmin(req: AuthRequest, res: Response, next: NextFunction): void {
  if (!req.authUser) {
    res.status(401).json({ error: 'Não autenticado.' });
    return;
  }
  const store = getStore();
  const userRec = store.users[req.authUser.uid];
  const allowed =
    isBootstrappedAdmin(req.authUser) ||
    (req.authUser.email_verified === true && userRec?.role === 'admin');
  if (!allowed) {
    addSecurityLog({
      level: 'warning',
      category: 'security',
      uid: req.authUser.uid,
      ip: getClientIp(req),
      message: 'Tentativa não autorizada de acesso ao painel administrativo.',
    });
    res.status(403).json({ error: 'Acesso restrito aos administradores da NovaHospeda.' });
    return;
  }
  next();
}

function renderStatusHtml(title: string, description: string, code: number): string {
  const safeTitle = title.replace(/[<>&"]/g, '');
  const safeDesc = description.replace(/[<>&"]/g, '');
  return `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${safeTitle} — NovaHospeda</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background: #f8fafc; color: #0f172a; margin: 0; display: flex; min-height: 100vh; align-items: center; justify-content: center; padding: 24px; }
    .card { max-width: 480px; width: 100%; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 32px; }
    .code { font-family: ui-monospace, monospace; font-size: 13px; color: #64748b; margin-bottom: 12px; }
    h1 { font-size: 22px; margin: 0 0 10px; font-weight: 700; }
    p { font-size: 15px; line-height: 1.6; color: #475569; margin: 0 0 24px; }
    a { display: inline-block; background: #1e40af; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 14px; padding: 10px 18px; border-radius: 8px; }
  </style>
</head>
<body>
  <main class="card">
    <div class="code">HTTP ${code} · NovaHospeda (${PRIMARY_DOMAIN})</div>
    <h1>${safeTitle}</h1>
    <p>${safeDesc}</p>
    <a href="/">Ir para NovaHospeda</a>
  </main>
</body>
</html>`;
}

function isHtmlPageRequest(filePath: string): boolean {
  const ext = path.posix.extname(filePath).toLowerCase();
  return ext === '.html' || ext === '.htm';
}

async function serveHostedStaticSite(
  req: Request,
  res: Response,
  site: SiteRecord,
  scope: string,
  subPath: string,
  trackVisit: boolean
): Promise<void> {
  if (trackVisit && site.status === 'blocked') {
    res
      .status(451)
      .type('text/html; charset=utf-8')
      .send(
        renderStatusHtml(
          'Site bloqueado por violação de política',
          'Este endereço foi suspenso pela moderação da NovaHospeda por violação dos Termos de Uso.',
          451
        )
      );
    return;
  }

  if (trackVisit && site.status === 'suspended') {
    res
      .status(503)
      .type('text/html; charset=utf-8')
      .send(
        renderStatusHtml(
          'Site temporariamente fora do ar',
          'O proprietário pausou temporariamente a publicação deste endereço.',
          503
        )
      );
    return;
  }

  if (!site.currentVersionId && scope === 'live') {
    res
      .status(404)
      .type('text/html; charset=utf-8')
      .send(
        renderStatusHtml(
          'Site aguardando primeira publicação',
          `O projeto "${site.name}" já reservou o subdomínio ${site.slug}.${PRIMARY_DOMAIN}, mas ainda não possui arquivos publicados.`,
          404
        )
      );
    return;
  }

  const rawCleaned = subPath.replace(/^\/+/, '');
  const candidateRel = rawCleaned === '' ? site.entryFile : rawCleaned;
  let safeRel = sanitizeRelativePath(candidateRel);

  let fileBuf: Buffer | null = safeRel ? await storage.readFile(site.id, scope, safeRel) : null;

  // Support clean folder index (e.g. /sobre -> /sobre/index.html)
  if (!fileBuf && safeRel && !path.posix.extname(safeRel)) {
    const folderIndex = `${safeRel}/index.html`;
    const folderBuf = await storage.readFile(site.id, scope, folderIndex);
    if (folderBuf) {
      safeRel = folderIndex;
      fileBuf = folderBuf;
    } else {
      const htmlExt = `${safeRel}.html`;
      const htmlBuf = await storage.readFile(site.id, scope, htmlExt);
      if (htmlBuf) {
        safeRel = htmlExt;
        fileBuf = htmlBuf;
      }
    }
  }

  if (!fileBuf) {
    const custom404 = await storage.readFile(site.id, scope, '404.html');
    if (custom404) {
      res.status(404).type('text/html; charset=utf-8').send(custom404);
      return;
    }
    res
      .status(404)
      .type('text/html; charset=utf-8')
      .send(
        renderStatusHtml(
          'Página não encontrada',
          `O arquivo solicitado não existe em ${site.slug}.${PRIMARY_DOMAIN}.`,
          404
        )
      );
    return;
  }

  // Strict static hosting security headers (never execute user scripts on server)
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader(
    'Content-Security-Policy',
    "default-src * 'unsafe-inline' 'unsafe-eval' data: blob:; object-src 'none'; base-uri 'self';"
  );

  if (trackVisit && safeRel && isHtmlPageRequest(safeRel)) {
    const referrer = typeof req.headers.referer === 'string' ? req.headers.referer : '';
    const pageUrl = rawCleaned === '' ? '/' : `/${rawCleaned}`;
    recordRealVisit(site.id, pageUrl, referrer);
  }

  const mime = getMimeType(safeRel || 'index.html');
  res.setHeader('Content-Type', mime);
  res.send(fileBuf);
}

async function startServer(): Promise<void> {
  const app = express();
  app.set('trust proxy', 1);

  // Initialize store synchronously at boot
  getStore();

  // Optional HTTPS redirect when behind Cloudflare / reverse proxy
  app.use((req: Request, res: Response, next: NextFunction) => {
    if (
      process.env.FORCE_HTTPS === 'true' &&
      req.headers['x-forwarded-proto'] === 'http'
    ) {
      const host = req.headers.host || PRIMARY_DOMAIN;
      res.redirect(301, `https://${host}${req.originalUrl}`);
      return;
    }
    next();
  });

  // Real subdomain routing: nomedosite.nh.com.br -> serves published static site directly!
  app.use(async (req: Request, res: Response, next: NextFunction) => {
    const hostHeader = (req.headers.host || '').split(':')[0].toLowerCase();
    const domainSuffix = `.${PRIMARY_DOMAIN.toLowerCase()}`;
    if (
      hostHeader.endsWith(domainSuffix) &&
      hostHeader !== PRIMARY_DOMAIN.toLowerCase() &&
      hostHeader !== `www.${PRIMARY_DOMAIN.toLowerCase()}`
    ) {
      const slug = hostHeader.slice(0, -domainSuffix.length);
      if (slug && !slug.includes('.')) {
        const site = findSiteBySlug(slug);
        if (!site) {
          res
            .status(404)
            .type('text/html; charset=utf-8')
            .send(
              renderStatusHtml(
                'Subdomínio disponível na NovaHospeda',
                `O endereço ${slug}.${PRIMARY_DOMAIN} ainda não foi publicado. Crie sua conta grátis e publique seu site agora!`,
                404
              )
            );
          return;
        }
        await serveHostedStaticSite(req, res, site, 'live', req.path, true);
        return;
      }
    }
    next();
  });

  // Live immediate public static site routes (work in external browsers and mobile immediately!)
  app.get('/sites/:slug', (req: Request, res: Response, next: NextFunction) => {
    if (req.path.endsWith('/')) {
      next();
      return;
    }
    const slug = String(req.params.slug || '');
    const qs = req.originalUrl.includes('?') ? req.originalUrl.slice(req.originalUrl.indexOf('?')) : '';
    res.redirect(302, `/sites/${encodeURIComponent(slug)}/${qs}`);
  });

  app.get('/sites/:slug/*', async (req: Request, res: Response) => {
    const slug = String(req.params.slug || '');
    const site = findSiteBySlug(slug);
    if (!site) {
      res
        .status(404)
        .type('text/html; charset=utf-8')
        .send(
          renderStatusHtml(
            'Site não encontrado',
            `Nenhum site publicado foi encontrado para o subdomínio "${slug}.${PRIMARY_DOMAIN}".`,
            404
          )
        );
      return;
    }
    const subPath = (req.params as Record<string, string>)[0] || '';
    await serveHostedStaticSite(req, res, site, 'live', subPath, true);
  });

  // Token-in-path preview route: preserves auth across CSS, JS, images, fonts, and subpages on all mobile & iframe browsers
  app.get('/p/:token/:siteId/:scope', (req: Request, res: Response, next: NextFunction) => {
    if (req.path.endsWith('/')) {
      next();
      return;
    }
    const { token, siteId, scope } = req.params;
    const qs = req.originalUrl.includes('?') ? req.originalUrl.slice(req.originalUrl.indexOf('?')) : '';
    res.redirect(
      302,
      `/p/${encodeURIComponent(token)}/${encodeURIComponent(siteId)}/${encodeURIComponent(scope)}/${qs}`
    );
  });

  app.get('/p/:token/:siteId/:scope/*', async (req: Request, res: Response) => {
    const { token, siteId, scope } = req.params;
    if (!verifyPreviewToken(token, siteId)) {
      res
        .status(403)
        .type('text/html; charset=utf-8')
        .send(
          renderStatusHtml(
            'Pré-visualização expirada ou não autorizada',
            'Gere uma nova pré-visualização a partir do painel ou editor da NovaHospeda.',
            403
          )
        );
      return;
    }
    const store = getStore();
    const site = store.sites[siteId];
    if (!site) {
      res
        .status(404)
        .type('text/html; charset=utf-8')
        .send(renderStatusHtml('Site não encontrado', 'Este projeto não existe ou foi removido.', 404));
      return;
    }
    if (scope === 'draft' && site.currentVersionId) {
      const draftFiles = await storage.listFiles(siteId, 'draft');
      if (draftFiles.length === 0) {
        await storage.copyVersionToDraft(siteId, site.currentVersionId);
      }
    }
    const subPath = (req.params as Record<string, string>)[0] || '';
    await serveHostedStaticSite(req, res, site, scope, subPath, false);
  });

  // Legacy query-token preview route (supports cookie + referer token fallback for relative sub-assets)
  app.get('/preview/:siteId/:scope', (req: Request, res: Response, next: NextFunction) => {
    if (req.path.endsWith('/')) {
      next();
      return;
    }
    const { siteId, scope } = req.params;
    const qs = req.originalUrl.includes('?') ? req.originalUrl.slice(req.originalUrl.indexOf('?')) : '';
    res.redirect(302, `/preview/${encodeURIComponent(siteId)}/${encodeURIComponent(scope)}/${qs}`);
  });

  app.get('/preview/:siteId/:scope/*', async (req: Request, res: Response) => {
    const { siteId, scope } = req.params;
    const queryToken = typeof req.query.token === 'string' ? req.query.token : '';
    const cookieToken = getCookieValue(req, `nh_preview_${siteId}`);
    const refToken = extractTokenFromReferer(req);
    const candidateToken = queryToken || cookieToken || refToken;

    if (!verifyPreviewToken(candidateToken, siteId)) {
      res
        .status(403)
        .type('text/html; charset=utf-8')
        .send(
          renderStatusHtml(
            'Pré-visualização expirada ou não autorizada',
            'Gere uma nova pré-visualização a partir do painel ou editor da NovaHospeda.',
            403
          )
        );
      return;
    }

    if (queryToken) {
      const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
      res.setHeader(
        'Set-Cookie',
        `nh_preview_${siteId}=${encodeURIComponent(queryToken)}; Path=/preview/${encodeURIComponent(siteId)}; HttpOnly; ${
          isHttps ? 'SameSite=None; Secure' : 'SameSite=Lax'
        }`
      );
    }

    const store = getStore();
    const site = store.sites[siteId];
    if (!site) {
      res.status(404).send('Site não encontrado.');
      return;
    }
    if (scope === 'draft' && site.currentVersionId) {
      const draftFiles = await storage.listFiles(siteId, 'draft');
      if (draftFiles.length === 0) {
        await storage.copyVersionToDraft(siteId, site.currentVersionId);
      }
    }
    const subPath = (req.params as Record<string, string>)[0] || '';
    await serveHostedStaticSite(req, res, site, scope, subPath, false);
  });

  // Body parsing & Rate limiting for API endpoints
  app.use('/api', express.json({ limit: '5mb' }));

  const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 240,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Muitas requisições em sequência. Aguarde alguns segundos.' },
  });

  const uploadLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 30,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
      addSecurityLog({
        level: 'warning',
        category: 'security',
        uid: null,
        ip: getClientIp(req),
        message: 'Rate limit de upload excedido.',
      });
      res.status(429).json({
        error: 'Limite temporário de uploads atingido. Aguarde alguns minutos e tente novamente.',
      });
    },
  });

  const reportLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Limite de denúncias por hora atingido.' },
  });

  const aiLimiter = rateLimit({
    windowMs: 10 * 60 * 1000,
    max: 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Muitas análises de IA seguidas. Aguarde alguns minutos.' },
  });

  app.use('/api', apiLimiter);

  // Configure dynamic multer upload limit up to 250MB hard ceiling (per-site limit enforced dynamically)
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 250 * 1024 * 1024,
      files: 300,
    },
  });

  // --- Public API Routes ---
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ status: 'ok', domain: PRIMARY_DOMAIN, storage: storage.driverName });
  });

  app.get('/api/public/info', (req: Request, res: Response) => {
    const store = getStore();
    const proto =
      typeof req.headers['x-forwarded-proto'] === 'string'
        ? req.headers['x-forwarded-proto'].split(',')[0].trim()
        : req.protocol;
    const reqHost = typeof req.headers.host === 'string' ? req.headers.host.trim() : '';
    const origin = reqHost
      ? `${proto}://${reqHost}`
      : process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL'
      ? process.env.APP_URL
      : 'http://localhost:3000';

    res.json({
      primaryDomain: PRIMARY_DOMAIN,
      appOrigin: origin,
      limits: store.limits,
      announcements: store.announcements.filter((a) => a.active),
      stats: {
        totalPublishedSites: Object.values(store.sites).filter((s) => s.status === 'online' && s.currentVersionId).length,
      },
    });
  });

  app.get('/api/subdomains/check', (req: Request, res: Response) => {
    const raw = typeof req.query.slug === 'string' ? req.query.slug : '';
    const excludeSiteId = typeof req.query.excludeSiteId === 'string' ? req.query.excludeSiteId : '';
    const check = validateSubdomainSlug(raw);
    if (!check.valid) {
      res.json({
        available: false,
        slug: check.slug,
        reason: check.reason,
        fullDomain: check.slug ? `${check.slug}.${PRIMARY_DOMAIN}` : '',
      });
      return;
    }

    const existing = findSiteBySlug(check.slug);
    if (existing && existing.id !== excludeSiteId) {
      res.json({
        available: false,
        slug: check.slug,
        reason: `O endereço ${check.slug}.${PRIMARY_DOMAIN} já está em uso.`,
        fullDomain: `${check.slug}.${PRIMARY_DOMAIN}`,
      });
      return;
    }

    res.json({
      available: true,
      slug: check.slug,
      fullDomain: `${check.slug}.${PRIMARY_DOMAIN}`,
    });
  });

  app.get('/api/subdomains/suggest', (req: Request, res: Response) => {
    const rawName = typeof req.query.name === 'string' ? req.query.name : '';
    const excludeSiteId = typeof req.query.excludeSiteId === 'string' ? req.query.excludeSiteId : '';
    const suggestions = generateAvailableDomainSuggestions(
      rawName,
      (slug) => {
        const existing = findSiteBySlug(slug);
        return Boolean(existing && existing.id !== excludeSiteId);
      },
      PRIMARY_DOMAIN
    );
    res.json({
      primaryDomain: PRIMARY_DOMAIN,
      suggestions,
    });
  });

  app.post('/api/reports', reportLimiter, async (req: Request, res: Response) => {
    const { siteSlug, reason, details, reporterEmail } = req.body || {};
    const cleanSlug = String(siteSlug || '').trim().toLowerCase();
    const cleanReason = String(reason || '').trim();
    const cleanDetails = String(details || '').trim();
    const cleanEmail = String(reporterEmail || '').trim();

    if (!cleanSlug || cleanReason.length < 3 || cleanDetails.length < 10) {
      res.status(400).json({ error: 'Informe o subdomínio, motivo e detalhes da denúncia.' });
      return;
    }

    const store = getStore();
    const matchedSite = findSiteBySlug(cleanSlug);
    const report: AbuseReportRecord = {
      id: crypto.randomUUID(),
      siteSlug: cleanSlug,
      siteId: matchedSite?.id || null,
      reason: cleanReason.slice(0, 120),
      details: cleanDetails.slice(0, 1500),
      reporterEmail: cleanEmail.slice(0, 200),
      status: 'open',
      createdAt: new Date().toISOString(),
      resolvedAt: null,
    };

    store.reports.unshift(report);
    addSecurityLog({
      level: 'warning',
      category: 'security',
      uid: null,
      ip: getClientIp(req),
      message: `Nova denúncia recebida para o subdomínio ${cleanSlug}.${PRIMARY_DOMAIN} (${report.reason}).`,
    });
    await persistStore();

    res.status(201).json({ ok: true, id: report.id });
  });

  // --- Authenticated User API Routes ---
  app.post('/api/auth/sync', requireAuth, async (req: AuthRequest, res: Response) => {
    const token = req.authUser!;
    const store = getStore();
    const now = new Date().toISOString();
    const requestedName =
      typeof req.body?.displayName === 'string' && req.body.displayName.trim()
        ? req.body.displayName.trim().slice(0, 100)
        : '';

    const existing = store.users[token.uid];
    if (!existing && !store.limits.allowSignups && !isBootstrappedAdmin(token)) {
      res.status(403).json({ error: 'Novos cadastros estão temporariamente pausados pela administração.' });
      return;
    }

    const role =
      isBootstrappedAdmin(token) || existing?.role === 'admin' ? 'admin' : 'user';
    const user: UserRecord = {
      uid: token.uid,
      displayName:
        requestedName ||
        (typeof token.name === 'string' && token.name) ||
        existing?.displayName ||
        (token.email ? token.email.split('@')[0] : 'Usuário'),
      email: token.email || existing?.email || '',
      emailVerified: token.email_verified === true,
      role,
      status: existing?.status || 'active',
      createdAt: existing?.createdAt || now,
      updatedAt: now,
      lastLoginAt: now,
    };

    store.users[token.uid] = user;
    if (!existing) {
      addSecurityLog({
        level: 'info',
        category: 'auth',
        uid: token.uid,
        ip: getClientIp(req),
        message: `Nova conta registrada: ${user.email}`,
      });
    }
    await persistStore();

    res.json({ user, limits: store.limits });
  });

  app.get('/api/me', requireAuth, (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const store = getStore();
    const user = store.users[uid];
    const sites = findUserSites(uid);
    const storageUsedBytes = getUserStorageUsed(uid);
    const totalVisits = sites.reduce((sum, s) => sum + (store.analytics[s.id]?.totalVisits || 0), 0);

    res.json({
      user: user || {
        uid,
        displayName: req.authUser!.name || req.authUser!.email || 'Usuário',
        email: req.authUser!.email || '',
        emailVerified: req.authUser!.email_verified === true,
        role: isBootstrappedAdmin(req.authUser!) ? 'admin' : 'user',
        status: 'active',
      },
      limits: store.limits,
      summary: {
        sitesCount: sites.length,
        publishedSitesCount: sites.filter((s) => s.status === 'online' && s.currentVersionId).length,
        storageUsedBytes,
        totalVisits,
      },
    });
  });

  // --- Site Management Routes ---
  app.get('/api/sites', requireAuth, (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const store = getStore();
    const sites = findUserSites(uid).map((site) => ({
      ...site,
      totalVisits: store.analytics[site.id]?.totalVisits || 0,
      lastVisitAt: store.analytics[site.id]?.lastVisitAt || null,
      deploymentsCount: (store.deployments[site.id] || []).length,
    }));
    res.json({ sites, limits: store.limits });
  });

  app.post('/api/sites', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const store = getStore();

    if (store.limits.maintenanceMode && !isBootstrappedAdmin(req.authUser!)) {
      res.status(503).json({ error: 'Plataforma em modo de manutenção. Tente novamente em instantes.' });
      return;
    }

    const userSites = findUserSites(uid);
    if (userSites.length >= store.limits.maxSitesPerUser && !isBootstrappedAdmin(req.authUser!)) {
      res.status(403).json({
        error: `Limite do plano gratuito atingido: máximo de ${store.limits.maxSitesPerUser} sites por conta.`,
      });
      return;
    }

    const name = String(req.body?.name || '').trim();
    const rawSlug = String(req.body?.slug || '').trim().toLowerCase();
    if (name.length < 2 || name.length > 80) {
      res.status(400).json({ error: 'O nome do site deve ter entre 2 e 80 caracteres.' });
      return;
    }

    const slugCheck = validateSubdomainSlug(rawSlug);
    if (!slugCheck.valid) {
      res.status(400).json({ error: slugCheck.reason || 'Subdomínio inválido.' });
      return;
    }

    if (findSiteBySlug(slugCheck.slug)) {
      res.status(409).json({ error: `O endereço ${slugCheck.slug}.${PRIMARY_DOMAIN} já está em uso.` });
      return;
    }

    const now = new Date().toISOString();
    const siteId = `site_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
    const site: SiteRecord = {
      id: siteId,
      ownerId: uid,
      ownerEmail: req.authUser!.email || '',
      name,
      slug: slugCheck.slug,
      customDomain: '',
      status: 'online',
      currentVersionId: null,
      draftVersionId: null,
      versionCount: 0,
      totalSizeBytes: 0,
      fileCount: 0,
      entryFile: 'index.html',
      sslEnabled: true,
      createdAt: now,
      updatedAt: now,
      lastPublishedAt: null,
    };

    store.sites[siteId] = site;
    store.deployments[siteId] = [];
    store.analytics[siteId] = {
      totalVisits: 0,
      dailyVisits: {},
      pageHits: {},
      referrers: {},
      lastVisitAt: null,
    };

    addSecurityLog({
      level: 'info',
      category: 'domain',
      uid,
      ip: getClientIp(req),
      message: `Site criado: ${site.name} (${site.slug}.${PRIMARY_DOMAIN})`,
    });
    await persistStore();

    res.status(201).json({ site });
  });

  app.patch('/api/sites/:siteId', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    if (site.status === 'blocked') {
      res.status(403).json({ error: 'Este site foi bloqueado pela moderação e não pode ser alterado.' });
      return;
    }

    const { name, slug, status, customDomain } = req.body || {};

    if (typeof name === 'string') {
      const cleanName = name.trim();
      if (cleanName.length < 2 || cleanName.length > 80) {
        res.status(400).json({ error: 'O nome do site deve ter entre 2 e 80 caracteres.' });
        return;
      }
      site.name = cleanName;
    }

    if (typeof slug === 'string') {
      const check = validateSubdomainSlug(slug);
      if (!check.valid) {
        res.status(400).json({ error: check.reason || 'Subdomínio inválido.' });
        return;
      }
      const conflict = findSiteBySlug(check.slug);
      if (conflict && conflict.id !== site.id) {
        res.status(409).json({ error: `O endereço ${check.slug}.${PRIMARY_DOMAIN} já está em uso.` });
        return;
      }
      site.slug = check.slug;
    }

    if (status === 'online' || status === 'suspended') {
      site.status = status;
    }

    if (typeof customDomain === 'string') {
      const cleanDomain = customDomain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      if (cleanDomain && !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(cleanDomain)) {
        res.status(400).json({ error: 'Informe um domínio próprio válido (ex: www.meudominio.com.br).' });
        return;
      }
      site.customDomain = cleanDomain;
    }

    site.updatedAt = new Date().toISOString();
    await persistStore();

    res.json({ site });
  });

  app.delete('/api/sites/:siteId', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    await storage.deleteSiteStorage(siteId);
    delete store.sites[siteId];
    delete store.deployments[siteId];
    delete store.analytics[siteId];

    addSecurityLog({
      level: 'info',
      category: 'domain',
      uid,
      ip: getClientIp(req),
      message: `Site excluído pelo usuário: ${site.slug}.${PRIMARY_DOMAIN}`,
    });
    await persistStore();

    res.json({ ok: true });
  });

  app.get('/api/sites/:siteId/deployments', requireAuth, (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const store = getStore();
    const site = store.sites[siteId];
    if (!site || (site.ownerId !== uid && !isBootstrappedAdmin(req.authUser!))) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }
    res.json({ deployments: store.deployments[siteId] || [] });
  });

  // --- Upload & Auto-Publish Pipeline ---
  app.post(
    '/api/sites/:siteId/upload',
    uploadLimiter,
    requireAuth,
    requireVerifiedEmail,
    upload.array('files', 300),
    async (req: AuthRequest, res: Response) => {
      const uid = req.authUser!.uid;
      const { siteId } = req.params;
      const store = getStore();
      const site = store.sites[siteId];

      if (!site || site.ownerId !== uid) {
        res.status(404).json({ error: 'Site não encontrado.' });
        return;
      }

      if (site.status === 'blocked') {
        res.status(403).json({ error: 'Este site foi bloqueado pela administração.' });
        return;
      }

      const uploadedFiles = (req.files as Express.Multer.File[]) || [];
      if (uploadedFiles.length === 0) {
        res.status(400).json({ error: 'Nenhum arquivo enviado.' });
        return;
      }

      const maxSiteBytes = store.limits.maxSiteSizeMb * 1024 * 1024;
      const autoPublish = req.body?.publish !== 'false';
      const notes = typeof req.body?.notes === 'string' ? req.body.notes.trim().slice(0, 240) : '';

      let relativePaths: string[] = [];
      if (typeof req.body?.relativePaths === 'string') {
        try {
          const parsed = JSON.parse(req.body.relativePaths);
          if (Array.isArray(parsed)) relativePaths = parsed.map(String);
        } catch {
          relativePaths = [];
        }
      }

      try {
        let extractedFiles: ExtractedFile[] = [];
        let totalSizeBytes = 0;
        let entryFile = 'index.html';
        let sourceType: DeploymentSourceType = 'files';
        let strippedFolder: string | null = null;

        const isSingleZip =
          uploadedFiles.length === 1 &&
          uploadedFiles[0].originalname.toLowerCase().endsWith('.zip');

        if (isSingleZip) {
          sourceType = 'zip';
          const zipResult = await safelyExtractZip(uploadedFiles[0].buffer, maxSiteBytes);
          extractedFiles = zipResult.files;
          totalSizeBytes = zipResult.totalSizeBytes;
          entryFile = zipResult.entryFile;
          strippedFolder = zipResult.strippedWrapperFolder;
        } else {
          const hasZipMixed = uploadedFiles.some((f) => f.originalname.toLowerCase().endsWith('.zip'));
          if (hasZipMixed) {
            res.status(400).json({
              error: 'Envie apenas um arquivo .zip por vez, ou envie arquivos estáticos individuais.',
            });
            return;
          }

          for (let i = 0; i < uploadedFiles.length; i++) {
            const file = uploadedFiles[i];
            const desiredPath = relativePaths[i] || file.originalname;
            const safeRel = sanitizeRelativePath(desiredPath);
            if (!safeRel) {
              throw new Error(`Nome de arquivo inválido: ${file.originalname}`);
            }
            const extCheck = validateStaticFileExtension(safeRel);
            if (!extCheck.valid) {
              throw new Error(extCheck.reason || `Arquivo não permitido: ${safeRel}`);
            }
            totalSizeBytes += file.buffer.byteLength;
            if (totalSizeBytes > maxSiteBytes) {
              throw new Error(
                `Tamanho total excede o limite gratuito de ${store.limits.maxSiteSizeMb} MB por site.`
              );
            }
            extractedFiles.push({ path: safeRel, content: file.buffer });
          }

          const detected = detectEntryHtml(extractedFiles.map((f) => f.path));
          if (!detected) {
            throw new Error('Inclua pelo menos um arquivo index.html (ou página .html) para publicar o site.');
          }
          entryFile = detected;
          sourceType = uploadedFiles.length === 1 && entryFile.endsWith('.html') ? 'html' : 'files';
        }

        const versionNumber = site.versionCount + 1;
        const versionId = `ver_${versionNumber}_${Date.now()}`;

        await storage.writeVersion(site.id, versionId, extractedFiles);
        await storage.copyVersionToDraft(site.id, versionId);

        const now = new Date().toISOString();
        const deployments = store.deployments[site.id] || [];

        if (autoPublish) {
          for (const d of deployments) {
            if (d.status === 'published') d.status = 'archived';
          }
          await storage.promoteVersionToLive(site.id, versionId);
          site.currentVersionId = versionId;
          site.lastPublishedAt = now;
        }

        const deployment: DeploymentRecord = {
          id: versionId,
          siteId: site.id,
          ownerId: uid,
          versionNumber,
          status: autoPublish ? 'published' : 'archived',
          sourceType,
          sizeBytes: totalSizeBytes,
          fileCount: extractedFiles.length,
          entryFile,
          notes:
            notes ||
            (strippedFolder
              ? `ZIP extraído (pasta "${strippedFolder}" normalizada para raiz)`
              : `Upload ${sourceType.toUpperCase()} (${extractedFiles.length} arquivo(s))`),
          createdAt: now,
        };

        deployments.unshift(deployment);
        store.deployments[site.id] = deployments;

        site.draftVersionId = versionId;
        site.versionCount = versionNumber;
        site.totalSizeBytes = totalSizeBytes;
        site.fileCount = extractedFiles.length;
        site.entryFile = entryFile;
        site.updatedAt = now;

        addSecurityLog({
          level: 'info',
          category: 'upload',
          uid,
          ip: getClientIp(req),
          message: `Publicação v${versionNumber} para ${site.slug}.${PRIMARY_DOMAIN} (${extractedFiles.length} arquivos, ${totalSizeBytes} bytes).`,
        });
        await persistStore();

        res.status(201).json({
          site,
          deployment,
          files: extractedFiles.map((f) => ({ path: f.path, sizeBytes: f.content.byteLength })),
          strippedWrapperFolder: strippedFolder,
        });
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Erro ao processar arquivos enviados.';
        addSecurityLog({
          level: 'warning',
          category: 'security',
          uid,
          ip: getClientIp(req),
          message: `Upload rejeitado em ${site.slug}: ${message}`,
        });
        res.status(400).json({ error: message });
      }
    }
  );

  // --- Integrated File Manager & Editor Routes ---
  app.get('/api/sites/:siteId/files', requireAuth, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const scope = typeof req.query.scope === 'string' ? req.query.scope : 'draft';
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || (site.ownerId !== uid && !isBootstrappedAdmin(req.authUser!))) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    let files = await storage.listFiles(siteId, scope);
    if (files.length === 0 && scope === 'draft' && site.currentVersionId) {
      await storage.copyVersionToDraft(siteId, site.currentVersionId);
      files = await storage.listFiles(siteId, 'draft');
    }

    res.json({ files, scope });
  });

  app.get('/api/sites/:siteId/file', requireAuth, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const filePath = typeof req.query.path === 'string' ? req.query.path : '';
    const scope = typeof req.query.scope === 'string' ? req.query.scope : 'draft';
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || (site.ownerId !== uid && !isBootstrappedAdmin(req.authUser!))) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    const buf = await storage.readFile(siteId, scope, filePath);
    if (!buf) {
      res.status(404).json({ error: 'Arquivo não encontrado.' });
      return;
    }

    res.json({
      path: filePath,
      content: buf.toString('utf8'),
      sizeBytes: buf.byteLength,
    });
  });

  app.put('/api/sites/:siteId/file', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const { path: rawPath, content } = req.body || {};
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    if (site.status === 'blocked') {
      res.status(403).json({ error: 'Site bloqueado pela administração.' });
      return;
    }

    const safeRel = sanitizeRelativePath(String(rawPath || ''));
    if (!safeRel) {
      res.status(400).json({ error: 'Caminho de arquivo inválido.' });
      return;
    }

    const extCheck = validateStaticFileExtension(safeRel);
    if (!extCheck.valid) {
      res.status(400).json({ error: extCheck.reason || 'Extensão não permitida.' });
      return;
    }

    if (typeof content !== 'string') {
      res.status(400).json({ error: 'Conteúdo do arquivo deve ser texto.' });
      return;
    }

    const buf = Buffer.from(content, 'utf8');
    const maxBytes = store.limits.maxSiteSizeMb * 1024 * 1024;
    const existingFiles = await storage.listFiles(siteId, 'draft');
    const prevSize = existingFiles.find((f) => f.path === safeRel)?.sizeBytes || 0;
    const currentTotal = existingFiles.reduce((sum, f) => sum + f.sizeBytes, 0);
    if (currentTotal - prevSize + buf.byteLength > maxBytes) {
      res.status(400).json({
        error: `Edição excederia o limite de ${store.limits.maxSiteSizeMb} MB do site.`,
      });
      return;
    }

    // Write exact unmodified user code to draft workspace
    await storage.writeDraftFile(siteId, safeRel, buf);
    const updatedFiles = await storage.listFiles(siteId, 'draft');

    res.json({ ok: true, path: safeRel, files: updatedFiles });
  });

  app.delete('/api/sites/:siteId/file', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const rawPath = typeof req.query.path === 'string' ? req.query.path : '';
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    const safeRel = sanitizeRelativePath(rawPath);
    if (!safeRel) {
      res.status(400).json({ error: 'Caminho inválido.' });
      return;
    }

    const deleted = await storage.deleteDraftFile(siteId, safeRel);
    if (!deleted) {
      res.status(404).json({ error: 'Arquivo não encontrado no rascunho.' });
      return;
    }

    const updatedFiles = await storage.listFiles(siteId, 'draft');
    res.json({ ok: true, files: updatedFiles });
  });

  app.post('/api/sites/:siteId/publish', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const notes = typeof req.body?.notes === 'string' ? req.body.notes.trim().slice(0, 240) : '';
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    if (site.status === 'blocked') {
      res.status(403).json({ error: 'Site bloqueado pela administração.' });
      return;
    }

    const draftFiles = await storage.listFiles(siteId, 'draft');
    if (draftFiles.length === 0) {
      res.status(400).json({ error: 'Não há arquivos no rascunho para publicar.' });
      return;
    }

    const entryFile = detectEntryHtml(draftFiles.map((f) => f.path));
    if (!entryFile) {
      res.status(400).json({ error: 'Crie ou envie um arquivo index.html antes de publicar.' });
      return;
    }

    const versionNumber = site.versionCount + 1;
    const versionId = `ver_${versionNumber}_${Date.now()}`;
    const snap = await storage.snapshotDraftAsVersion(siteId, versionId);
    await storage.promoteVersionToLive(siteId, versionId);

    const now = new Date().toISOString();
    const deployments = store.deployments[siteId] || [];
    for (const d of deployments) {
      if (d.status === 'published') d.status = 'archived';
    }

    const deployment: DeploymentRecord = {
      id: versionId,
      siteId,
      ownerId: uid,
      versionNumber,
      status: 'published',
      sourceType: 'editor',
      sizeBytes: snap.totalSizeBytes,
      fileCount: snap.fileCount,
      entryFile,
      notes: notes || `Publicação via editor v${versionNumber}`,
      createdAt: now,
    };

    deployments.unshift(deployment);
    store.deployments[siteId] = deployments;

    site.currentVersionId = versionId;
    site.draftVersionId = versionId;
    site.versionCount = versionNumber;
    site.totalSizeBytes = snap.totalSizeBytes;
    site.fileCount = snap.fileCount;
    site.entryFile = entryFile;
    site.lastPublishedAt = now;
    site.updatedAt = now;

    await persistStore();
    res.json({ site, deployment });
  });

  app.post('/api/sites/:siteId/rollback/:versionId', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId, versionId } = req.params;
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    if (site.status === 'blocked') {
      res.status(403).json({ error: 'Site bloqueado pela administração.' });
      return;
    }

    const deployments = store.deployments[siteId] || [];
    const target = deployments.find((d) => d.id === versionId && d.status !== 'removed');
    if (!target) {
      res.status(404).json({ error: 'Versão solicitada não encontrada.' });
      return;
    }

    await storage.promoteVersionToLive(siteId, versionId);
    await storage.copyVersionToDraft(siteId, versionId);

    for (const d of deployments) {
      if (d.status === 'published') d.status = 'archived';
    }
    target.status = 'published';

    const now = new Date().toISOString();
    site.currentVersionId = versionId;
    site.totalSizeBytes = target.sizeBytes;
    site.fileCount = target.fileCount;
    site.entryFile = target.entryFile;
    site.lastPublishedAt = now;
    site.updatedAt = now;

    await persistStore();
    res.json({ site, deployment: target });
  });

  app.get('/api/sites/:siteId/preview-token', requireAuth, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const store = getStore();
    const site = store.sites[siteId];
    if (!site || (site.ownerId !== uid && !isBootstrappedAdmin(req.authUser!))) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }
    let draftFiles = await storage.listFiles(siteId, 'draft');
    if (draftFiles.length === 0 && site.currentVersionId) {
      await storage.copyVersionToDraft(siteId, site.currentVersionId);
      draftFiles = await storage.listFiles(siteId, 'draft');
    }
    const token = createPreviewToken(siteId, uid);
    res.json({
      token,
      previewPath: `/p/${encodeURIComponent(token)}/${siteId}/draft/`,
      hasDraftFiles: draftFiles.length > 0,
      hasLiveFiles: Boolean(site.currentVersionId),
    });
  });

  // Create clean starter files for a new site so user can preview and edit right away
  app.post('/api/sites/:siteId/starter', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    if (site.status === 'blocked') {
      res.status(403).json({ error: 'Site bloqueado pela administração.' });
      return;
    }

    const safeTitle = site.name.replace(/[<>&"]/g, '');
    const starterFiles: ExtractedFile[] = [
      {
        path: 'index.html',
        content: Buffer.from(
          `<!doctype html>\n<html lang="pt-BR">\n<head>\n  <meta charset="utf-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>${safeTitle}</title>\n  <link rel="stylesheet" href="style.css" />\n</head>\n<body>\n  <main class="container">\n    <h1>${safeTitle}</h1>\n    <p>Site criado na NovaHospeda em <strong>${site.slug}.${PRIMARY_DOMAIN}</strong>.</p>\n    <button id="acao-btn" type="button">Testar interação</button>\n    <p id="status-msg"></p>\n  </main>\n  <script src="app.js"></script>\n</body>\n</html>\n`,
          'utf8'
        ),
      },
      {
        path: 'style.css',
        content: Buffer.from(
          `* { box-sizing: border-box; }\nbody {\n  margin: 0;\n  font-family: system-ui, -apple-system, sans-serif;\n  background: #f8fafc;\n  color: #0f172a;\n  min-height: 100vh;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 24px;\n}\n.container {\n  max-width: 560px;\n  width: 100%;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 32px;\n}\nh1 { margin: 0 0 12px; font-size: 28px; }\np { color: #475569; line-height: 1.6; }\nbutton {\n  margin-top: 12px;\n  background: #1d4ed8;\n  color: #fff;\n  border: 0;\n  border-radius: 8px;\n  padding: 10px 18px;\n  font-weight: 600;\n  cursor: pointer;\n}\nbutton:hover { background: #1e40af; }\n`,
          'utf8'
        ),
      },
      {
        path: 'app.js',
        content: Buffer.from(
          `document.getElementById('acao-btn')?.addEventListener('click', () => {\n  const msg = document.getElementById('status-msg');\n  if (msg) {\n    msg.textContent = 'Interação funcionando perfeitamente!';\n  }\n});\n`,
          'utf8'
        ),
      },
    ];

    for (const file of starterFiles) {
      await storage.writeDraftFile(siteId, file.path, file.content);
    }

    const files = await storage.listFiles(siteId, 'draft');
    res.status(201).json({ files });
  });

  // AI Site Error Diagnostic & Fix Proposal
  app.post('/api/sites/:siteId/ai-fix', aiLimiter, requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const userPrompt = typeof req.body?.prompt === 'string' ? req.body.prompt.slice(0, 1000) : '';
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    let draftFiles = await storage.listFiles(siteId, 'draft');
    if (draftFiles.length === 0 && site.currentVersionId) {
      await storage.copyVersionToDraft(siteId, site.currentVersionId);
      draftFiles = await storage.listFiles(siteId, 'draft');
    }

    const textFiles = draftFiles.filter((f) => f.isText);
    if (textFiles.length === 0) {
      res.status(400).json({ error: 'Este site ainda não possui arquivos HTML, CSS ou JS para analisar.' });
      return;
    }

    const loadedFiles = [];
    for (const f of textFiles) {
      const buf = await storage.readFile(siteId, 'draft', f.path);
      if (buf) {
        loadedFiles.push({ path: f.path, content: buf.toString('utf8') });
      }
    }

    try {
      const result = await analyzeAndFixSiteWithAI({
        siteName: site.name,
        files: loadedFiles,
        userPrompt,
      });

      // Validate all returned patch file paths against security rules
      const safePatches = result.patches.filter((p) => {
        const clean = sanitizeRelativePath(p.path);
        if (!clean) return false;
        return validateStaticFileExtension(clean).valid;
      }).map((p) => ({
        ...p,
        path: sanitizeRelativePath(p.path)!,
      }));

      addSecurityLog({
        level: 'info',
        category: 'upload',
        uid,
        ip: getClientIp(req),
        message: `Análise de IA executada em ${site.slug}.${PRIMARY_DOMAIN} (${safePatches.length} correção(ões) sugerida(s)).`,
      });

      res.json({
        summary: result.summary,
        diagnostics: result.diagnostics,
        patches: safePatches,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao executar análise com IA.';
      res.status(500).json({ error: msg });
    }
  });

  // Apply approved AI patches to site draft (never modifies live site without user preview/publish)
  app.post('/api/sites/:siteId/ai-apply', requireAuth, requireVerifiedEmail, async (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const patches = Array.isArray(req.body?.patches) ? req.body.patches : [];
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || site.ownerId !== uid) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    if (site.status === 'blocked') {
      res.status(403).json({ error: 'Site bloqueado pela administração.' });
      return;
    }

    if (patches.length === 0) {
      res.status(400).json({ error: 'Nenhuma correção selecionada para aplicar.' });
      return;
    }

    const appliedPaths: string[] = [];
    for (const patch of patches) {
      const safeRel = sanitizeRelativePath(String(patch?.path || ''));
      if (!safeRel) continue;
      if (!validateStaticFileExtension(safeRel).valid) continue;
      if (typeof patch?.fixedContent !== 'string') continue;

      const buf = Buffer.from(patch.fixedContent, 'utf8');
      await storage.writeDraftFile(siteId, safeRel, buf);
      appliedPaths.push(safeRel);
    }

    const updatedFiles = await storage.listFiles(siteId, 'draft');
    res.json({ ok: true, appliedPaths, files: updatedFiles });
  });

  // --- Real Analytics Routes ---
  app.get('/api/sites/:siteId/analytics', requireAuth, (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const { siteId } = req.params;
    const days = Math.min(90, Math.max(7, Number(req.query.days) || 14));
    const store = getStore();
    const site = store.sites[siteId];

    if (!site || (site.ownerId !== uid && !isBootstrappedAdmin(req.authUser!))) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }

    const record = store.analytics[siteId] || {
      totalVisits: 0,
      dailyVisits: {},
      pageHits: {},
      referrers: {},
      lastVisitAt: null,
    };

    const dailySeries: Array<{ date: string; visits: number }> = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      dailySeries.push({ date: d, visits: record.dailyVisits[d] || 0 });
    }

    const topPages = Object.entries(record.pageHits)
      .map(([page, hits]) => ({ page, hits }))
      .sort((a, b) => b.hits - a.hits)
      .slice(0, 10);

    const topReferrers = Object.entries(record.referrers)
      .map(([source, hits]) => ({ source, hits }))
      .sort((a, b) => b.hits - a.hits)
      .slice(0, 10);

    res.json({
      totalVisits: record.totalVisits,
      lastVisitAt: record.lastVisitAt,
      dailySeries,
      topPages,
      topReferrers,
    });
  });

  app.get('/api/analytics/overview', requireAuth, (req: AuthRequest, res: Response) => {
    const uid = req.authUser!.uid;
    const days = Math.min(90, Math.max(7, Number(req.query.days) || 14));
    const store = getStore();
    const userSites = findUserSites(uid);

    const dailyTotals: Record<string, number> = {};
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      dailyTotals[d] = 0;
    }

    let totalVisits = 0;
    const topSites = userSites.map((site) => {
      const stats = store.analytics[site.id];
      const siteVisits = stats?.totalVisits || 0;
      totalVisits += siteVisits;
      if (stats) {
        for (const dayKey of Object.keys(dailyTotals)) {
          dailyTotals[dayKey] += stats.dailyVisits[dayKey] || 0;
        }
      }
      return {
        id: site.id,
        name: site.name,
        slug: site.slug,
        visits: siteVisits,
        sizeBytes: site.totalSizeBytes,
        status: site.status,
      };
    }).sort((a, b) => b.visits - a.visits);

    const dailySeries = Object.entries(dailyTotals).map(([date, visits]) => ({ date, visits }));

    res.json({
      totalVisits,
      totalStorageBytes: getUserStorageUsed(uid),
      sitesCount: userSites.length,
      dailySeries,
      topSites,
    });
  });

  // --- Admin Panel Routes ---
  app.get('/api/admin/overview', requireAuth, requireAdmin, async (_req: AuthRequest, res: Response) => {
    const store = getStore();
    const diskUsageBytes = await storage.getDiskUsageBytes();
    const mem = process.memoryUsage();

    const users = Object.values(store.users).map((u) => {
      const sites = findUserSites(u.uid);
      return {
        ...u,
        sitesCount: sites.length,
        storageUsedBytes: sites.reduce((sum, s) => sum + s.totalSizeBytes, 0),
      };
    });

    const sites = Object.values(store.sites).map((s) => ({
      ...s,
      totalVisits: store.analytics[s.id]?.totalVisits || 0,
      deploymentsCount: (store.deployments[s.id] || []).length,
    }));

    const totalVisitsAll = sites.reduce((sum, s) => sum + s.totalVisits, 0);

    res.json({
      users,
      sites,
      reports: store.reports,
      announcements: store.announcements,
      securityLogs: store.securityLogs.slice(0, 120),
      limits: store.limits,
      infrastructure: {
        storageDriver: storage.driverName,
        diskUsageBytes,
        heapUsedBytes: mem.heapUsed,
        rssBytes: mem.rss,
        uptimeSeconds: Math.floor(process.uptime()),
        nodeVersion: process.version,
        platform: `${os.platform()} ${os.arch()}`,
        totalVisitsAll,
      },
    });
  });

  app.post('/api/admin/users/:uid/status', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const targetUid = req.params.uid;
    const status = req.body?.status === 'suspended' ? 'suspended' : 'active';
    const store = getStore();
    const target = store.users[targetUid];
    if (!target) {
      res.status(404).json({ error: 'Usuário não encontrado.' });
      return;
    }
    if (target.email === BOOTSTRAPPED_ADMIN_EMAIL) {
      res.status(400).json({ error: 'Não é possível suspender o administrador principal.' });
      return;
    }
    target.status = status;
    target.updatedAt = new Date().toISOString();
    addSecurityLog({
      level: status === 'suspended' ? 'warning' : 'info',
      category: 'admin',
      uid: req.authUser!.uid,
      ip: getClientIp(req),
      message: `Admin alterou status do usuário ${target.email} para ${status}.`,
    });
    await persistStore();
    res.json({ user: target });
  });

  app.post('/api/admin/sites/:siteId/status', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const { siteId } = req.params;
    const status = req.body?.status;
    if (status !== 'online' && status !== 'suspended' && status !== 'blocked') {
      res.status(400).json({ error: 'Status inválido.' });
      return;
    }
    const store = getStore();
    const site = store.sites[siteId];
    if (!site) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }
    site.status = status;
    site.updatedAt = new Date().toISOString();
    addSecurityLog({
      level: status === 'blocked' ? 'critical' : 'info',
      category: 'admin',
      uid: req.authUser!.uid,
      ip: getClientIp(req),
      message: `Admin definiu site ${site.slug}.${PRIMARY_DOMAIN} como "${status}".`,
    });
    await persistStore();
    res.json({ site });
  });

  app.delete('/api/admin/sites/:siteId', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const { siteId } = req.params;
    const store = getStore();
    const site = store.sites[siteId];
    if (!site) {
      res.status(404).json({ error: 'Site não encontrado.' });
      return;
    }
    await storage.deleteSiteStorage(siteId);
    delete store.sites[siteId];
    delete store.deployments[siteId];
    delete store.analytics[siteId];
    addSecurityLog({
      level: 'critical',
      category: 'admin',
      uid: req.authUser!.uid,
      ip: getClientIp(req),
      message: `Admin removeu permanentemente o site ${site.slug}.${PRIMARY_DOMAIN}.`,
    });
    await persistStore();
    res.json({ ok: true });
  });

  app.put('/api/admin/limits', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const store = getStore();
    const { maxSitesPerUser, maxSiteSizeMb, allowSignups, maintenanceMode } = req.body || {};

    if (typeof maxSitesPerUser === 'number' && maxSitesPerUser >= 1 && maxSitesPerUser <= 100) {
      store.limits.maxSitesPerUser = Math.floor(maxSitesPerUser);
    }
    if (typeof maxSiteSizeMb === 'number' && maxSiteSizeMb >= 1 && maxSiteSizeMb <= 2048) {
      store.limits.maxSiteSizeMb = Math.floor(maxSiteSizeMb);
    }
    if (typeof allowSignups === 'boolean') {
      store.limits.allowSignups = allowSignups;
    }
    if (typeof maintenanceMode === 'boolean') {
      store.limits.maintenanceMode = maintenanceMode;
    }
    store.limits.updatedAt = new Date().toISOString();

    addSecurityLog({
      level: 'info',
      category: 'admin',
      uid: req.authUser!.uid,
      ip: getClientIp(req),
      message: `Limites atualizados: ${store.limits.maxSitesPerUser} sites/usuário, ${store.limits.maxSiteSizeMb} MB/site.`,
    });
    await persistStore();
    res.json({ limits: store.limits });
  });

  app.post('/api/admin/announcements', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const { title, message, severity } = req.body || {};
    const cleanTitle = String(title || '').trim();
    const cleanMsg = String(message || '').trim();
    if (cleanTitle.length < 2 || cleanMsg.length < 2) {
      res.status(400).json({ error: 'Informe título e mensagem para o aviso.' });
      return;
    }
    const sev = severity === 'warning' || severity === 'maintenance' ? severity : 'info';
    const item: AnnouncementRecord = {
      id: `ann_${crypto.randomUUID().slice(0, 12)}`,
      title: cleanTitle.slice(0, 120),
      message: cleanMsg.slice(0, 600),
      severity: sev,
      active: true,
      createdAt: new Date().toISOString(),
    };
    const store = getStore();
    store.announcements.unshift(item);
    await persistStore();
    res.status(201).json({ announcement: item });
  });

  app.patch('/api/admin/announcements/:id', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const store = getStore();
    const item = store.announcements.find((a) => a.id === req.params.id);
    if (!item) {
      res.status(404).json({ error: 'Aviso não encontrado.' });
      return;
    }
    if (typeof req.body?.active === 'boolean') {
      item.active = req.body.active;
    }
    await persistStore();
    res.json({ announcement: item });
  });

  app.delete('/api/admin/announcements/:id', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const store = getStore();
    store.announcements = store.announcements.filter((a) => a.id !== req.params.id);
    await persistStore();
    res.json({ ok: true });
  });

  app.patch('/api/admin/reports/:reportId', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const store = getStore();
    const report = store.reports.find((r) => r.id === req.params.reportId);
    if (!report) {
      res.status(404).json({ error: 'Denúncia não encontrada.' });
      return;
    }
    const status = req.body?.status;
    if (status === 'resolved' || status === 'dismissed' || status === 'open') {
      report.status = status;
      report.resolvedAt = status === 'open' ? null : new Date().toISOString();
    }
    await persistStore();
    res.json({ report });
  });

  app.get('/api/admin/backup', requireAuth, requireAdmin, (req: AuthRequest, res: Response) => {
    const store = getStore();
    addSecurityLog({
      level: 'info',
      category: 'admin',
      uid: req.authUser!.uid,
      ip: getClientIp(req),
      message: 'Backup completo de metadados exportado pelo administrador.',
    });
    res.setHeader('Content-Disposition', `attachment; filename="novahospeda-backup-${new Date().toISOString().slice(0, 10)}.json"`);
    res.json(store);
  });

  // --- Frontend Serving (Vite Dev Middleware or Production Dist) ---
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      const indexPath = path.join(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Build dist/index.html não encontrado. Execute npm run build.');
      }
    });
  }

  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NovaHospeda server running on http://0.0.0.0:${PORT} (domain: ${PRIMARY_DOMAIN})`);
  });
}

startServer().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
