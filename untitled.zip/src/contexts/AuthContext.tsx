import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from 'firebase/auth';
import type { User } from 'firebase/auth';
import { doc, getDoc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { apiFetch } from '../lib/api';
import {
  OperationType,
  auth,
  db,
  googleAuthProvider,
  handleFirestoreError,
} from '../lib/firebase';
import type { PlatformLimits, UserProfile } from '../types/platform';

interface AuthContextValue {
  firebaseUser: User | null;
  profile: UserProfile | null;
  limits: PlatformLimits;
  loading: boolean;
  syncError: string | null;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  registerWithEmail: (name: string, email: string, password: string) => Promise<void>;
  sendResetPassword: (email: string) => Promise<void>;
  resendVerification: () => Promise<void>;
  refreshVerification: () => Promise<boolean>;
  updateDisplayName: (name: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const DEFAULT_LIMITS: PlatformLimits = {
  maxSitesPerUser: 3,
  maxSiteSizeMb: 100,
  allowSignups: true,
  maintenanceMode: false,
  primaryDomain: 'nh.com.br',
  updatedAt: '',
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [limits, setLimits] = useState<PlatformLimits>(DEFAULT_LIMITS);
  const [loading, setLoading] = useState(true);
  const [syncError, setSyncError] = useState<string | null>(null);

  const syncWithBackendAndFirestore = useCallback(async (user: User, explicitName?: string) => {
    setSyncError(null);
    const data = await apiFetch<{ user: UserProfile; limits: PlatformLimits }>('/api/auth/sync', {
      method: 'POST',
      body: JSON.stringify({ displayName: explicitName || user.displayName || '' }),
    });
    setProfile(data.user);
    setLimits(data.limits);

    // Sync user profile to Firestore when email is verified (required by security rules)
    if (user.emailVerified) {
      const userPath = `users/${user.uid}`;
      const userRef = doc(db, 'users', user.uid);
      try {
        const snap = await getDoc(userRef);
        if (!snap.exists()) {
          await setDoc(userRef, {
            uid: user.uid,
            displayName: data.user.displayName,
            email: user.email || data.user.email,
            role: data.user.role,
            status: data.user.status,
            sitesCount: 0,
            storageUsedBytes: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else {
          await updateDoc(userRef, {
            displayName: data.user.displayName,
            updatedAt: serverTimestamp(),
          });
        }
      } catch (err) {
        // Log structured Firestore error without blocking backend-verified session
        try {
          handleFirestoreError(err, OperationType.WRITE, userPath);
        } catch (logged) {
          console.warn('Firestore profile sync skipped:', logged);
        }
      }
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (!user) {
        setProfile(null);
        setSyncError(null);
        setLoading(false);
        return;
      }

      try {
        await syncWithBackendAndFirestore(user);
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Erro ao carregar perfil da conta.';
        setSyncError(msg);
      } finally {
        setLoading(false);
      }
    });
    return () => unsubscribe();
  }, [syncWithBackendAndFirestore]);

  const loginWithGoogle = async () => {
    const cred = await signInWithPopup(auth, googleAuthProvider);
    await syncWithBackendAndFirestore(cred.user);
  };

  const loginWithEmail = async (email: string, password: string) => {
    const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
    await syncWithBackendAndFirestore(cred.user);
  };

  const registerWithEmail = async (name: string, email: string, password: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
    await updateProfile(cred.user, { displayName: name.trim() });
    await sendEmailVerification(cred.user);
    await syncWithBackendAndFirestore(cred.user, name.trim());
  };

  const sendResetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  };

  const resendVerification = async () => {
    if (!auth.currentUser) throw new Error('Usuário não autenticado.');
    await sendEmailVerification(auth.currentUser);
  };

  const refreshVerification = async (): Promise<boolean> => {
    if (!auth.currentUser) return false;
    await auth.currentUser.reload();
    await auth.currentUser.getIdToken(true);
    const updatedUser = auth.currentUser;
    setFirebaseUser(updatedUser);
    if (updatedUser.emailVerified) {
      await syncWithBackendAndFirestore(updatedUser);
    }
    return updatedUser.emailVerified;
  };

  const updateDisplayName = async (name: string) => {
    if (!auth.currentUser) throw new Error('Usuário não autenticado.');
    const clean = name.trim();
    if (clean.length < 2) throw new Error('Informe um nome com pelo menos 2 caracteres.');
    await updateProfile(auth.currentUser, { displayName: clean });
    await syncWithBackendAndFirestore(auth.currentUser, clean);
  };

  const refreshProfile = async () => {
    if (!auth.currentUser) return;
    await syncWithBackendAndFirestore(auth.currentUser);
  };

  const logout = async () => {
    await signOut(auth);
    setProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        limits,
        loading,
        syncError,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        sendResetPassword,
        resendVerification,
        refreshVerification,
        updateDisplayName,
        logout,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider');
  return ctx;
}
