import path from 'node:path';
import JSZip from 'jszip';

export const BOOTSTRAPPED_ADMIN_EMAIL = 'dvenancio767@gmail.com';
const rawPrimaryDomain = (process.env.NH_PRIMARY_DOMAIN || process.env.PRIMARY_DOMAIN || '').trim();
export const PRIMARY_DOMAIN =
  rawPrimaryDomain && rawPrimaryDomain.includes('.') && !/^\d+$/.test(rawPrimaryDomain)
    ? rawPrimaryDomain
    : 'nh.com.br';

export const RESERVED_SUBDOMAINS = new Set<string>([
  'www', 'api', 'admin', 'root', 'mail', 'smtp', 'imap', 'pop', 'ftp', 'sftp', 'ssh',
  'ns1', 'ns2', 'ns3', 'dns', 'cdn', 'app', 'panel', 'painel', 'dashboard', 'console',
  'auth', 'login', 'logout', 'signup', 'register', 'cadastro', 'conta', 'account',
  'static', 'assets', 'media', 'img', 'images', 'files', 'uploads', 'status', 'health',
  'docs', 'doc', 'help', 'ajuda', 'support', 'suporte', 'billing', 'planos', 'plans',
  'novahospeda', 'nh', 'localhost', 'test', 'teste', 'dev', 'staging', 'preview',
  'sites', 'site', 's', 'report', 'abuse', 'denuncia', 'terms', 'termos', 'privacy',
  'privacidade', 'ssl', 'cert', 'acme', 'well-known', 'robots', 'sitemap', 'webmail',
  'cloud', 'edge', 'proxy', 'portal',
]);

export const ALLOWED_STATIC_EXTENSIONS = new Set<string>([
  '.html', '.htm', '.css', '.js', '.mjs', '.cjs', '.json', '.svg',
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.avif', '.ico', '.bmp',
  '.woff', '.woff2', '.ttf', '.otf', '.eot',
  '.txt', '.xml', '.webmanifest', '.map', '.md', '.csv',
  '.mp4', '.webm', '.ogg', '.mp3', '.wav', '.pdf',
]);

export const BLOCKED_EXECUTABLE_EXTENSIONS = new Set<string>([
  '.php', '.php3', '.php4', '.php5', '.phtml', '.phar',
  '.py', '.pyc', '.rb', '.pl', '.cgi', '.sh', '.bash', '.zsh',
  '.exe', '.bat', '.cmd', '.com', '.msi', '.dll', '.so', '.dylib',
  '.jsp', '.jspx', '.asp', '.aspx', '.ashx', '.asmx',
  '.htaccess', '.htpasswd', '.env', '.ini', '.conf',
]);

export const TEXT_EDITABLE_EXTENSIONS = new Set<string>([
  '.html', '.htm', '.css', '.js', '.mjs', '.json', '.svg',
  '.txt', '.xml', '.webmanifest', '.md', '.csv',
]);

const MIME_MAP: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.cjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.bmp': 'image/bmp',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.eot': 'application/vnd.ms-fontobject',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.csv': 'text/csv; charset=utf-8',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.ogg': 'audio/ogg',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.pdf': 'application/pdf',
};

export function getMimeType(filePath: string): string {
  const ext = path.extname(filePath).toLowerCase();
  return MIME_MAP[ext] || 'application/octet-stream';
}

export function isTextEditable(filePath: string): boolean {
  const ext = path.extname(filePath).toLowerCase();
  return TEXT_EDITABLE_EXTENSIONS.has(ext);
}

export function normalizeSlug(raw: string): string {
  return raw
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

export function validateSubdomainSlug(rawSlug: string): { valid: boolean; slug: string; reason?: string } {
  const slug = rawSlug.trim().toLowerCase();
  if (slug.length < 3 || slug.length > 48) {
    return { valid: false, slug, reason: 'O subdomínio deve ter entre 3 e 48 caracteres.' };
  }
  if (!/^[a-z0-9]([a-z0-9-]{1,46}[a-z0-9])$/.test(slug)) {
    return {
      valid: false,
      slug,
      reason: 'Use apenas letras minúsculas (a-z), números (0-9) e hífens no meio.',
    };
  }
  if (slug.includes('--')) {
    return { valid: false, slug, reason: 'O subdomínio não pode conter dois hífens seguidos (--).' };
  }
  if (RESERVED_SUBDOMAINS.has(slug)) {
    return { valid: false, slug, reason: `O subdomínio "${slug}" é reservado pela plataforma.` };
  }
  return { valid: true, slug };
}

export interface DomainSuggestion {
  slug: string;
  fullDomain: string;
  isExactMatch: boolean;
}

export function generateAvailableDomainSuggestions(
  siteName: string,
  isSlugTaken: (slug: string) => boolean,
  primaryDomain = PRIMARY_DOMAIN
): DomainSuggestion[] {
  let base = normalizeSlug(siteName);
  if (!base || base.length < 3) {
    base = base ? `${base}-site` : 'meu-app';
  }
  if (base.length > 36) {
    base = base.slice(0, 36).replace(/-+$/g, '');
  }

  const candidateBases = [
    base,
    `${base}-app`,
    `${base}-site`,
    `${base}-web`,
    `${base}-br`,
    `${base}-online`,
    `app-${base}`,
    `site-${base}`,
    `${base}-oficial`,
  ];

  // Add deterministic numbered fallbacks in case all common variants are taken
  for (let n = 1; n <= 9; n++) {
    candidateBases.push(`${base}-${n}`);
  }

  const suggestions: DomainSuggestion[] = [];
  const seen = new Set<string>();

  for (let i = 0; i < candidateBases.length; i++) {
    const raw = candidateBases[i].replace(/--+/g, '-').replace(/^-|-$/g, '').slice(0, 48);
    if (seen.has(raw)) continue;
    seen.add(raw);

    const check = validateSubdomainSlug(raw);
    if (!check.valid) continue;
    if (isSlugTaken(check.slug)) continue;

    suggestions.push({
      slug: check.slug,
      fullDomain: `${check.slug}.${primaryDomain}`,
      isExactMatch: i === 0,
    });

    if (suggestions.length >= 6) break;
  }

  return suggestions;
}

export function sanitizeRelativePath(rawPath: string): string | null {
  if (!rawPath || rawPath.includes('\0')) return null;
  const unified = rawPath.replace(/\\/g, '/').trim().replace(/^\/+/, '');
  if (!unified || unified.length > 240) return null;

  const segments = unified.split('/').filter((s) => s.length > 0);
  if (segments.length === 0) return null;

  for (const seg of segments) {
    if (seg === '.' || seg === '..' || seg.includes('..') || /[\x00-\x1f<>:"|?*]/.test(seg)) {
      return null;
    }
  }

  return segments.join('/');
}

export function validateStaticFileExtension(relPath: string): { valid: boolean; reason?: string } {
  const baseName = path.posix.basename(relPath).toLowerCase();
  if (baseName === '.htaccess' || baseName === '.env' || baseName.startsWith('.git')) {
    return { valid: false, reason: `Arquivo restrito por segurança: ${relPath}` };
  }
  const ext = path.posix.extname(relPath).toLowerCase();
  if (!ext) {
    return { valid: false, reason: `Arquivo sem extensão permitida: ${relPath}` };
  }
  if (BLOCKED_EXECUTABLE_EXTENSIONS.has(ext)) {
    return { valid: false, reason: `Execução de scripts no servidor não é permitida (${ext}): ${relPath}` };
  }
  if (!ALLOWED_STATIC_EXTENSIONS.has(ext)) {
    return { valid: false, reason: `Extensão não suportada para hospedagem estática (${ext}): ${relPath}` };
  }
  return { valid: true };
}

export interface ExtractedFile {
  path: string;
  content: Buffer;
}

export interface ZipExtractionResult {
  files: ExtractedFile[];
  totalSizeBytes: number;
  entryFile: string;
  strippedWrapperFolder: string | null;
}

const MAX_ZIP_FILE_COUNT = 1500;

export async function safelyExtractZip(
  zipBuffer: Buffer,
  maxTotalBytes: number
): Promise<ZipExtractionResult> {
  if (zipBuffer.byteLength > maxTotalBytes) {
    throw new Error(`Arquivo ZIP excede o limite de ${(maxTotalBytes / (1024 * 1024)).toFixed(0)} MB.`);
  }

  // Verify ZIP magic header (PK)
  if (zipBuffer.byteLength < 4 || zipBuffer[0] !== 0x50 || zipBuffer[1] !== 0x4b) {
    throw new Error('O arquivo enviado não é um pacote ZIP válido.');
  }

  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(zipBuffer, { checkCRC32: true });
  } catch {
    throw new Error('Falha ao ler arquivo ZIP. Verifique se o pacote não está corrompido.');
  }

  const rawEntries: Array<{ rawPath: string; entry: JSZip.JSZipObject }> = [];
  for (const [entryName, entry] of Object.entries(zip.files)) {
    if (entry.dir) continue;
    const normalized = entryName.replace(/\\/g, '/');
    if (
      normalized.startsWith('__MACOSX/') ||
      normalized.includes('/__MACOSX/') ||
      path.posix.basename(normalized) === '.DS_Store' ||
      path.posix.basename(normalized) === 'Thumbs.db'
    ) {
      continue;
    }
    rawEntries.push({ rawPath: normalized, entry });
  }

  if (rawEntries.length === 0) {
    throw new Error('O arquivo ZIP não contém arquivos válidos.');
  }

  if (rawEntries.length > MAX_ZIP_FILE_COUNT) {
    throw new Error(`Proteção contra ZIP bomb: máximo de ${MAX_ZIP_FILE_COUNT} arquivos por publicação.`);
  }

  // Detect single top-level wrapper folder (e.g. "meu-site/index.html")
  let strippedWrapperFolder: string | null = null;
  const firstSegments = new Set<string>();
  let allHaveSubdir = true;
  for (const item of rawEntries) {
    const clean = item.rawPath.replace(/^\/+/, '');
    const parts = clean.split('/').filter(Boolean);
    if (parts.length < 2) {
      allHaveSubdir = false;
      break;
    }
    firstSegments.add(parts[0]);
  }
  const hasRootIndex = rawEntries.some(
    (item) => item.rawPath.replace(/^\/+/, '').toLowerCase() === 'index.html'
  );
  if (!hasRootIndex && allHaveSubdir && firstSegments.size === 1) {
    strippedWrapperFolder = Array.from(firstSegments)[0];
  }

  const extracted: ExtractedFile[] = [];
  let cumulativeBytes = 0;

  for (const item of rawEntries) {
    let targetPath = item.rawPath.replace(/^\/+/, '');
    if (strippedWrapperFolder && targetPath.startsWith(`${strippedWrapperFolder}/`)) {
      targetPath = targetPath.slice(strippedWrapperFolder.length + 1);
    }

    const safeRel = sanitizeRelativePath(targetPath);
    if (!safeRel) {
      throw new Error(`Caminho inseguro ou inválido detectado no ZIP: ${item.rawPath}`);
    }

    const extCheck = validateStaticFileExtension(safeRel);
    if (!extCheck.valid) {
      throw new Error(extCheck.reason || `Extensão bloqueada: ${safeRel}`);
    }

    // Stream/decompress while enforcing cumulative size limit to block ZIP bombs
    const buf = await item.entry.async('nodebuffer');
    cumulativeBytes += buf.byteLength;
    if (cumulativeBytes > maxTotalBytes) {
      throw new Error(
        `Proteção contra ZIP bomb: conteúdo descompactado ultrapassou o limite de ${(
          maxTotalBytes /
          (1024 * 1024)
        ).toFixed(0)} MB.`
      );
    }

    extracted.push({ path: safeRel, content: buf });
  }

  const entryFile = detectEntryHtml(extracted.map((f) => f.path));
  if (!entryFile) {
    throw new Error(
      'Nenhum arquivo index.html ou página HTML foi encontrado no pacote. Inclua um arquivo index.html na raiz ou pasta principal do ZIP.'
    );
  }

  return {
    files: extracted,
    totalSizeBytes: cumulativeBytes,
    entryFile,
    strippedWrapperFolder,
  };
}

export function detectEntryHtml(paths: string[]): string | null {
  const exactRoot = paths.find((p) => p.toLowerCase() === 'index.html');
  if (exactRoot) return exactRoot;
  const htmRoot = paths.find((p) => p.toLowerCase() === 'index.htm');
  if (htmRoot) return htmRoot;
  const nestedIndex = paths.find((p) => p.toLowerCase().endsWith('/index.html'));
  if (nestedIndex) return nestedIndex;
  const anyHtml = paths.find((p) => p.toLowerCase().endsWith('.html') || p.toLowerCase().endsWith('.htm'));
  return anyHtml || null;
}
